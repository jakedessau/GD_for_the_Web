
// horizantally invert img
$('img').addClass('rotate');

